#include <RtcDS1307.h>
#include <Wire.h>

RtcDS1307<TwoWire> Rtc(Wire);

void setup(){
  Serial.begin(9600);
  Rtc.Begin();
  Rtc.SetIsRunning(true);
  Rtc.SetDateTime(RtcDateTime(__DATE__, __TIME__));
}

void loop(){
  //DS1307时钟模块接开发板llc（A4，A5）

  Serial.print(String(String("Date") + String("：")) + String(String(Rtc.GetDateTime().Year()) + String("-")) + String(String(Rtc.GetDateTime().Month()) + String("-")) + String(String(Rtc.GetDateTime().Day()) + String("-")));
  Serial.println(String(String("Time") + String("：")) + String(String(Rtc.GetDateTime().Hour()) + String("-")) + String(String(Rtc.GetDateTime().Minute()) + String("-")) + String(Rtc.GetDateTime().Second()));

}
